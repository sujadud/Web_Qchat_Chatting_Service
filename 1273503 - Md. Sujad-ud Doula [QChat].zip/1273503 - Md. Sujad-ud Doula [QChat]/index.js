const express = require('express');
const app = express();
var http = require('http').createServer(app);
var io = require('socket.io')(http);
var formidable = require('formidable');
http.listen(8080, () => {
    console.log('listening on http://localhost:8080');
});
app.use('/files', express.static('files'));

app.get('/img/chat-icon.png', (req, res) => {
    res.sendFile(__dirname + '/img/chat-icon.png');
});
app.get('/img/background.gif', (req, res) => {
    res.sendFile(__dirname + '/img/background.gif');
});
app.get('/img/chat-background.png', (req, res) => {
    res.sendFile(__dirname + '/img/chat-background.png');
});
app.get('/lib/jquery-3.4.1.min.js', (req, res) => {
    res.sendFile(__dirname + '/lib/jquery-3.4.1.min.js');
});
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/signup.html');
});

app.get('/chat', (req, res) => {
    res.sendFile(__dirname + '/chat.html');
});
io.on('connection', (socket) => {
    console.log('a user connected');
    socket.on('disconnect', () => {
        console.log('user disconnected');
    });
    socket.on('chat message', (msg) => {
        //console.log(msg);
        io.emit('chat message', msg);
    });
});
app.post('/uploadfile', function (req, res){
    var strFilePath = '';
    var form = new formidable.IncomingForm();
    form.parse(req);
    form.on('fileBegin', function (name, file){
        file.path = __dirname + '/files/' + file.name;
    });
    form.on('file', function (name, file){
        strFilePath = '/files/' + file.name;
        res.send(JSON.stringify({"filePath":strFilePath,"fileName":file.name}));
    });
});
